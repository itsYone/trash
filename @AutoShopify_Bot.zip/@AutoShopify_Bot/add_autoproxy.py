import re

with open('E:/@AutoShopify_Bot/bot.py', 'r', encoding='utf-8') as f:
    code = f.read()

autoproxy_code = """
@client.on(events.NewMessage(pattern='/autoproxy'))
async def auto_proxy(event):
    if event.is_group:
        return await event.reply("🔒 𝙏𝙝𝙞𝙨 𝙘𝙤𝙢𝙢𝙖𝙣𝙙 𝙤𝙣𝙡𝙮 𝙬𝙤𝙧𝙠𝙨 𝙞𝙣 𝙥𝙧𝙞𝙫𝙖𝙩𝙚 𝙘𝙝𝙖𝙩!")
    
    if await is_banned_user(event.sender_id):
        return await event.reply(banned_user_message())
        
    msg = await event.reply("🔄 **𝙎𝙘𝙧𝙖𝙥𝙞𝙣𝙜 & 𝙏𝙚𝙨𝙩𝙞𝙣𝙜 𝙋𝙧𝙤𝙭𝙞𝙚𝙨...**\\n\\n*𝙏𝙝𝙞𝙨 𝙬𝙞𝙡𝙡 𝙛𝙞𝙣𝙙 𝙩𝙝𝙚 10 𝙛𝙖𝙨𝙩𝙚𝙨𝙩 𝙬𝙤𝙧𝙠𝙞𝙣𝙜 𝙥𝙧𝙤𝙭𝙞𝙚𝙨. 𝙋𝙡𝙚𝙖𝙨𝙚 𝙬𝙖𝙞𝙩 (30𝙨)...* ⏳")
    
    try:
        import time, asyncio
        import aiohttp
        
        # 1. Scrape proxies
        urls = [
            "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
            "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=5000&country=all&ssl=all&anonymity=all"
        ]
        
        scraped_proxies = set()
        async with aiohttp.ClientSession() as session:
            for url in urls:
                try:
                    async with session.get(url, timeout=5) as res:
                        if res.status == 200:
                            text = await res.text()
                            for line in text.splitlines():
                                line = line.strip()
                                if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+$', line):
                                    scraped_proxies.add(line)
                except: pass
                
        if not scraped_proxies:
            return await msg.edit("❌ **𝙁𝙖𝙞𝙡𝙚𝙙 𝙩𝙤 𝙨𝙘𝙧𝙖𝙥𝙚 𝙥𝙧𝙤𝙭𝙞𝙚𝙨.**")
            
        proxy_list = list(scraped_proxies)[:200] # Test 200 max to save time
        
        # 2. Test proxies concurrently
        working_proxies = []
        
        async def check_proxy(proxy_str):
            proxy_url = f"http://{proxy_str}"
            start_time = time.time()
            try:
                # Test against ipify
                timeout = aiohttp.ClientTimeout(total=4)
                async with aiohttp.ClientSession(timeout=timeout) as test_session:
                    async with test_session.get("http://api.ipify.org?format=json", proxy=proxy_url) as res:
                        if res.status == 200:
                            elapsed = time.time() - start_time
                            working_proxies.append({'proxy_str': proxy_str, 'proxy_url': proxy_url, 'time': elapsed})
            except: pass

        tasks = [check_proxy(p) for p in proxy_list]
        await asyncio.gather(*tasks)
        
        # 3. Sort by fastest
        working_proxies.sort(key=lambda x: x['time'])
        fastest = working_proxies[:10] # Get top 10
        
        if not fastest:
            return await msg.edit("❌ **𝘼𝙡𝙡 200 𝙩𝙚𝙨𝙩𝙚𝙙 𝙥𝙧𝙤𝙭𝙞𝙚𝙨 𝙬𝙚𝙧𝙚 𝙙𝙚𝙖𝙙. 𝙏𝙧𝙮 𝙖𝙜𝙖𝙞𝙣 𝙡𝙖𝙩𝙚𝙧.**")
            
        # 4. Save to user's profile
        proxies = await load_json(PROXY_FILE)
        user_proxies = proxies.get(str(event.sender_id), [])
        
        # Format for proxy.json
        new_proxies_added = 0
        for p in fastest:
            if len(user_proxies) >= 10: break # Max 10 limit
            ip, port = p['proxy_str'].split(':')
            
            # Check if exists
            exists = False
            for existing in user_proxies:
                if existing['proxy_url'] == p['proxy_url']:
                    exists = True
                    break
            
            if not exists:
                user_proxies.append({
                    'ip': ip,
                    'port': port,
                    'username': None,
                    'password': None,
                    'proxy_url': p['proxy_url'],
                    'type': 'http'
                })
                new_proxies_added += 1
                
        proxies[str(event.sender_id)] = user_proxies
        await save_json(PROXY_FILE, proxies)
        
        time_msg = "\\n".join([f"✅ `{p['proxy_str']}` - {p['time']:.2f}s" for p in fastest[:new_proxies_added]])
        
        await msg.edit(f"🎉 **𝙎𝙪𝙘𝙘𝙚𝙨𝙨𝙛𝙪𝙡𝙡𝙮 𝙖𝙙𝙙𝙚𝙙 {new_proxies_added} 𝙛𝙖𝙨𝙩 𝙥𝙧𝙤𝙭𝙞𝙚𝙨!**\\n\\n**𝙏𝙤𝙥 𝙎𝙥𝙚𝙚𝙙𝙨:**\\n{time_msg}\\n\\n𝙐𝙨𝙚 /proxy 𝙩𝙤 𝙫𝙞𝙚𝙬 𝙩𝙝𝙚𝙢!")
        
    except Exception as e:
        await msg.edit(f"❌ 𝙀𝙧𝙧𝙤𝙧: {str(e)}")

"""

# Insert right before start command
code = code.replace("@client.on(events.NewMessage(pattern=r'(?i)^[/.](start|cmds?|commands?)$'))", autoproxy_code + "\n@client.on(events.NewMessage(pattern=r'(?i)^[/.](start|cmds?|commands?)$'))")

with open('E:/@AutoShopify_Bot/bot.py', 'w', encoding='utf-8') as f:
    f.write(code)

print("Added /autoproxy successfully")
