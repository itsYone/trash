import requests
import re
import os

print("Scraping fresh HTTP proxies...")
urls = [
    "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
    "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all"
]

proxies = set()

for url in urls:
    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            lines = response.text.strip().split('\n')
            for line in lines:
                line = line.strip()
                # Match IP:PORT format
                if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+$', line):
                    proxies.add(line)
    except Exception as e:
        print(f"Failed to scrape from {url}: {e}")

proxy_list = list(proxies)[:500] # Limit to 500

with open("scraped_proxies.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(proxy_list))

print(f"Successfully scraped and saved {len(proxy_list)} proxies to scraped_proxies.txt")
