import re

with open('E:/@AutoShopify_Bot/bot.py', 'r', encoding='utf-8') as f:
    code = f.read()

# Replace all occurrences of the old API URL
old_api_1 = "url = f'https://teamoicxkiller.online/code/index.php?cc={card}&url={selected_site}'"
new_api_1 = "url = f'http://62.72.20.10:8081/?{card}&url={selected_site}'"
code = code.replace(old_api_1, new_api_1)

old_api_2 = "url = f'https://teamoicxkiller.online/code/index.php?cc={card}&url={site}'"
new_api_2 = "url = f'http://62.72.20.10:8081/?{card}&url={site}'"
code = code.replace(old_api_2, new_api_2)

old_api_3 = "url = f'https://teamoicxkiller.online/code/index.php?cc={test_card}&url={site}'"
new_api_3 = "url = f'http://62.72.20.10:8081/?{test_card}&url={site}'"
code = code.replace(old_api_3, new_api_3)

with open('E:/@AutoShopify_Bot/bot.py', 'w', encoding='utf-8') as f:
    f.write(code)

print("Modifications applied successfully.")
