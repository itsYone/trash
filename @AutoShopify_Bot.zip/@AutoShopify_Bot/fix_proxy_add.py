with open('E:/@AutoShopify_Bot/bot.py', 'r', encoding='utf-8') as f:
    code = f.read()

# Fix the /add overlapping with /addpxy
code = code.replace("pattern='/add'", "pattern=r'(?i)^/add(?!pxy)'")

# Fix the test_proxy hitting http instead of https
code = code.replace("'http://api.ipify.org?format=json'", "'https://api.ipify.org?format=json'")

with open('E:/@AutoShopify_Bot/bot.py', 'w', encoding='utf-8') as f:
    f.write(code)

print("Modifications applied successfully.")
