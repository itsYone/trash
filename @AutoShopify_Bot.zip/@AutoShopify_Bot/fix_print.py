with open('E:/@AutoShopify_Bot/bot.py', 'r', encoding='utf-8') as f:
    code = f.read()

# Fix the print statement causing the encoding error on Windows console
code = code.replace('print("𝘽𝙊𝙏 𝙍𝙐𝙉𝙉𝙄𝙉𝙂 💨")', 'print("BOT RUNNING...")')

with open('E:/@AutoShopify_Bot/bot.py', 'w', encoding='utf-8') as f:
    f.write(code)
print('Fixed encoding bug')
