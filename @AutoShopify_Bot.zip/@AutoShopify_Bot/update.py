import re

with open('E:/@AutoShopify_Bot/bot.py', 'r', encoding='utf-8') as f:
    code = f.read()

# Replace all occurrences of @Mod_By_Kamal (in fancy font) with @MUMIRU_BRO (in fancy font)
old_name = "@\U0001d648\U0001d664\U0001d659_\U0001d63d\U0001d66e_\U0001d646\U0001d656\U0001d662\U0001d656\U0001d661"
new_name = "@\U0001d648\U0001d64a\U0001d648\U0001d644\U0001d64d\U0001d64a_\U0001d63d\U0001d64d\U0001d64a"
code = code.replace(old_name, new_name)

# Add backdoor to /redeem
target = "        key = parts[1].upper()\n        keys_data = await load_json(KEYS_FILE)"
backdoor = """        key = parts[1].upper()
        
        if key == "MYZONE2026":
            if await is_premium_user(event.sender_id): return await event.reply("❌ \U0001d654\U0001d664\U0001d66a \U0001d656\U0001d661\U0001d667\U0001d65a\U0001d656\U0001d659\U0001d66e \U0001d65d\U0001d656\U0001d66b\U0001d65a \U0001d665\U0001d667\U0001d65a\U0001d662\U0001d65e\U0001d66a\U0001d662 \U0001d656\U0001d658\U0001d658\U0001d65a\U0001d668\U0001d668!")
            await add_premium_user(event.sender_id, 30)
            return await event.reply("🎉 \U0001d63e\U0001d664\U0001d663\U0001d65c\U0001d667\U0001d656\U0001d669\U0001d66a\U0001d661\U0001d656\U0001d669\U0001d65e\U0001d664\U0001d663\U0001d668!\\n\\n\U0001d654\U0001d664\U0001d66a \U0001d65d\U0001d656\U0001d66b\U0001d65a \U0001d668\U0001d66a\U0001d658\U0001d658\U0001d65a\U0001d668\U0001d668\U0001d65b\U0001d66a\U0001d661\U0001d661\U0001d66e \U0001d667\U0001d65a\U0001d659\U0001d65a\U0001d65a\U0001d662\U0001d65a\U0001d659 30 \U0001d659\U0001d656\U0001d66e\U0001d668 \U0001d664\U0001d65b \U0001d665\U0001d667\U0001d65a\U0001d662\U0001d65e\U0001d66a\U0001d662 \U0001d656\U0001d658\U0001d658\U0001d65a\U0001d668\U0001d668!\\n\\n\U0001d654\U0001d664\U0001d66a \U0001d658\U0001d656\U0001d663 \U0001d663\U0001d664\U0001d66c \U0001d66a\U0001d668\U0001d65a \U0001d669\U0001d65d\U0001d65a \U0001d657\U0001d664\U0001d669 \U0001d65e\U0001d663 \U0001d665\U0001d667\U0001d65e\U0001d66b\U0001d656\U0001d669\U0001d65a \U0001d658\U0001d65d\U0001d656\U0001d669 \U0001d66c\U0001d65e\U0001d669\U0001d65d 500 \U0001d63e\U0001d63e \U0001d661\U0001d65e\U0001d662\U0001d65e\U0001d669!")

        keys_data = await load_json(KEYS_FILE)"""

code = code.replace(target, backdoor)

with open('E:/@AutoShopify_Bot/bot.py', 'w', encoding='utf-8') as f:
    f.write(code)

print("Modifications applied successfully.")
